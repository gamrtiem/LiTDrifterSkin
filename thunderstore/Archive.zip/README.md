# Lost in Transit Drifter
adds lost in transit's drifter as a skin for alloyed collective drifter !!!!!! !! ! !!! !!!

<details>
  <summary>screenshots !!!</summary>
  
![drifter css (she looks significantly better in game trust me !!!](https://files.catbox.moe/sub2b7.png)

![drifter in game !!](https://files.catbox.moe/u7mi3o.png)

![drifter holding evil and devious skull .,,.](https://files.catbox.moe/wqr3p0.png)

</details>

config to entirely nuke original drifter and replace her icon with LiTs for all the real drifter model haters out there !!!!!!!!!!! (disabled by default(

![](https://files.catbox.moe/uf8212.png)

### known small issues,.,,.
- the back of inside her hoodie sometimes clips while using repossess ,.,.., 
- bag looks a little silly while salvaging .,,. 


### credits ,..,.
* bruh - LiT drifter model !!!!
* acanthi - umm was awesome and mades drifter armature fix python script !!!
* swuff - drifter when ,.,.., 
* brynzananas - helped me in skin creating channel during a time of need ,..,,.., 
* hifu - hi hifu !!! 


<br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br>


![](https://files.catbox.moe/rxp0r9.gif)

![](https://files.catbox.moe/bnrgd1.gif)

<sub>old model in gif so weight paints are a little weird but its fine shush itll be a little secret between us !!!<sub>
